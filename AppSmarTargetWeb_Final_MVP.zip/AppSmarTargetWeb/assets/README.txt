Coloque aqui:
logo-smarTarget.png
bg-metas.jpg
